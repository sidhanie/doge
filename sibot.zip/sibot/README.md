# Link DogeClickBot Telegram
Hargai Refferal : https://t.me/Dogecoin_click_bot?start=GZ0V 

# Cara Install 
$ apt update && apt upgrade<br>
$ apt install python git<br>
$ git clone https://github.com/kyo1337/dogeclickbot<br>
$ cd dogeclickbot<br>
$ pip3 install -r requirements.txt<br>
$ python3 main.py phone_number<br>

# Note :
- Bisa Menggunakan Nomor Luar/ID, Syarat Input Nomor :
  python main.py 62813******
- Input OTP
- And Happy Mining

# Media Sosial :
- https://www.duitkeun.xyz